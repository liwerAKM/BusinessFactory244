﻿using System;

namespace OnlineBusHos_Tran
{
    public class Class1
    {
    }
}
